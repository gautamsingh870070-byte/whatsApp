

@extends('layouts.app')

@section('content')
<style>
    .card-profile {
        gap: 16px;
        align-items: center;
    }
    .icon-wrapper {
        width: 56px;
        height: 56px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
        flex-shrink: 0;
        box-shadow: 0 4px 12px rgba(0,0,0,0.05);
    }
    .icon-blue { background-color: var(--icon-bg-blue, #eff6ff); color: var(--icon-color-blue, #3b82f6); }
    .icon-green { background-color: var(--icon-bg-green, #f0fdf4); color: var(--icon-color-green, #22c55e); }
    .icon-purple { background-color: var(--icon-bg-purple, #faf5ff); color: var(--icon-color-purple, #a855f7); }
    .icon-yellow { background-color: #fefce8; color: #eab308; }
    .icon-red { background-color: #fef2f2; color: #ef4444; }

    .section-title {
        font-size: 20px;
        font-weight: 700;
        color: var(--text-main);
        margin: 32px 0 16px 0;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .card-content {
        display: flex;
        flex-direction: column;
        gap: 8px;
        width: 100%;
    }
    .card-title {
        font-size: 15px;
        color: var(--text-muted);
        font-weight: 500;
    }
    .card-value {
        font-size: 32px;
        font-weight: 700;
        color: var(--text-main);
        text-align: center;
        margin-top: 8px;
    }
    .card-greeting {
        font-size: 16px;
        font-weight: 500;
        color: var(--text-main);
    }
    .flex-row {
        display: flex;
        align-items: center;
        gap: 16px;
    }
</style>

<div class="grid">
    <!-- Card 1: User Profile -->
    <div class="card card-profile" style="background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%); color: white; border: none;">
        <div class="icon-wrapper" style="background-color: rgba(255,255,255,0.2); color: white; width: 64px; height: 64px; font-size: 28px;">
            <i class="fa-solid fa-user-tie"></i>
        </div>
        <div class="card-greeting" style="color: white; display: flex; flex-direction: column; gap: 4px; justify-content: center;">
            <div style="font-size: 13px; opacity: 0.8; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">Welcome back</div>
            <div style="font-size: 24px; font-weight: 700; line-height: 1; text-transform: capitalize;">{{ auth()->user()->role ?? 'User' }}</div>
            <div style="font-size: 15px; opacity: 0.9;">{{ auth()->user()->name }}</div>
        </div>
    </div>

    @if(auth()->user()->isSuperAdmin())
        <!-- Superadmin Cards -->
        <div class="card" style="background: linear-gradient(135deg, #0ea5e9 0%, #2563eb 100%); color: white; border: none;">
            <div class="card-content">
                <div class="flex-row">
                    <div class="icon-wrapper" style="background-color: rgba(255,255,255,0.2); color: white;">
                        <i class="fa-solid fa-users"></i>
                    </div>
                    <span class="card-title" style="color: rgba(255,255,255,0.85);">Total Users</span>
                </div>
                <div class="card-value" style="color: white;">{{ $roleStats['total_users'] }}</div>
            </div>
        </div>
        <div class="card" style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; border: none;">
            <div class="card-content">
                <div class="flex-row">
                    <div class="icon-wrapper" style="background-color: rgba(255,255,255,0.2); color: white;">
                        <i class="fa-solid fa-user-shield"></i>
                    </div>
                    <span class="card-title" style="color: rgba(255,255,255,0.85);">Total Admins</span>
                </div>
                <div class="card-value" style="color: white;">{{ $roleStats['total_admins'] }}</div>
            </div>
        </div>
        <div class="card" style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); color: white; border: none;">
            <div class="card-content">
                <div class="flex-row">
                    <div class="icon-wrapper" style="background-color: rgba(255,255,255,0.2); color: white;">
                        <i class="fa-solid fa-paper-plane"></i>
                    </div>
                    <span class="card-title" style="color: rgba(255,255,255,0.85);">Total Sent</span>
                </div>
                <div class="card-value" style="color: white;">{{ $totalWapp }}</div>
            </div>
        </div>
    @elseif(auth()->user()->isAdmin())
        <!-- Admin Cards -->
        <div class="card" style="background: linear-gradient(135deg, #0ea5e9 0%, #2563eb 100%); color: white; border: none;">
            <div class="card-content">
                <div class="flex-row">
                    <div class="icon-wrapper" style="background-color: rgba(255,255,255,0.2); color: white;">
                        <i class="fa-solid fa-users-viewfinder"></i>
                    </div>
                    <span class="card-title" style="color: rgba(255,255,255,0.85);">My Clients</span>
                </div>
                <div class="card-value" style="color: white;">{{ $roleStats['my_clients'] }}</div>
            </div>
        </div>
        <div class="card" style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; border: none;">
            <div class="card-content">
                <div class="flex-row">
                    <div class="icon-wrapper" style="background-color: rgba(255,255,255,0.2); color: white;">
                        <i class="fa-solid fa-coins"></i>
                    </div>
                    <span class="card-title" style="color: rgba(255,255,255,0.85);">Credits Available</span>
                </div>
                <div class="card-value" style="color: white;">{{ max(0, $roleStats['total_credits'] - $roleStats['credits_assigned']) }}</div>
            </div>
        </div>
        <div class="card" style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); color: white; border: none;">
            <div class="card-content">
                <div class="flex-row">
                    <div class="icon-wrapper" style="background-color: rgba(255,255,255,0.2); color: white;">
                        <i class="fa-solid fa-paper-plane"></i>
                    </div>
                    <span class="card-title" style="color: rgba(255,255,255,0.85);">Total Sent</span>
                </div>
                <div class="card-value" style="color: white;">{{ $totalWapp }}</div>
            </div>
        </div>
    @else
        <!-- Client Cards -->
        <div class="card" style="background: linear-gradient(135deg, #0ea5e9 0%, #2563eb 100%); color: white; border: none;">
            <div class="card-content">
                <div class="flex-row">
                    <div class="icon-wrapper" style="background-color: rgba(255,255,255,0.2); color: white;">
                        <i class="fa-solid fa-bolt"></i>
                    </div>
                    <span class="card-title" style="color: rgba(255,255,255,0.85);">Daily Limit</span>
                </div>
                <div class="card-value" style="color: white;">{{ $roleStats['daily_limit'] }}</div>
            </div>
        </div>
        <div class="card" style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; border: none;">
            <div class="card-content">
                <div class="flex-row">
                    <div class="icon-wrapper" style="background-color: rgba(255,255,255,0.2); color: white;">
                        <i class="fa-solid fa-chart-line"></i>
                    </div>
                    <span class="card-title" style="color: rgba(255,255,255,0.85);">Sent Today</span>
                </div>
                <div class="card-value" style="color: white;">{{ $roleStats['credits_used_today'] }}</div>
            </div>
        </div>
        <div class="card" style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); color: white; border: none;">
            <div class="card-content">
                <div class="flex-row">
                    <div class="icon-wrapper" style="background-color: rgba(255,255,255,0.2); color: white;">
                        <i class="fa-solid fa-paper-plane"></i>
                    </div>
                    <span class="card-title" style="color: rgba(255,255,255,0.85);">Total Sent</span>
                </div>
                <div class="card-value" style="color: white;">{{ $totalWapp }}</div>
            </div>
        </div>
    @endif
</div>

<!-- WhatsApp Statistics Section -->
<div class="section-title">
    <i class="fa-brands fa-whatsapp" style="color: #25D366;"></i> WhatsApp Statistics
</div>
<div class="grid">
    <!-- Total -->
    <div class="card">
        <div class="card-content">
            <div class="flex-row">
                <div class="icon-wrapper icon-blue">
                    <i class="fa-solid fa-list-check"></i>
                </div>
                <span class="card-title">Total</span>
            </div>
            <div class="card-value">{{ number_format($waTotal, 2) }}</div>
        </div>
    </div>

    <!-- Success -->
    <div class="card">
        <div class="card-content">
            <div class="flex-row">
                <div class="icon-wrapper icon-green">
                    <i class="fa-solid fa-check-double"></i>
                </div>
                <span class="card-title">Success</span>
            </div>
            <div class="card-value" style="color: #22c55e;">{{ number_format($waSuccess, 2) }}</div>
        </div>
    </div>

    <!-- Pending -->
    <div class="card">
        <div class="card-content">
            <div class="flex-row">
                <div class="icon-wrapper icon-yellow">
                    <i class="fa-solid fa-clock"></i>
                </div>
                <span class="card-title">Pending</span>
            </div>
            <div class="card-value" style="color: #eab308;">{{ number_format($waPending, 2) }}</div>
        </div>
    </div>

    <!-- Failed -->
    <div class="card">
        <div class="card-content">
            <div class="flex-row">
                <div class="icon-wrapper icon-red">
                    <i class="fa-solid fa-circle-xmark"></i>
                </div>
                <span class="card-title">Failed</span>
            </div>
            <div class="card-value" style="color: #ef4444;">{{ number_format($waFailed, 2) }}</div>
        </div>
    </div>
</div>
@endsection
