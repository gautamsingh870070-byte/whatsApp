@extends('layouts.app')

@section('content')
<style>
    .page-title {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 24px;
    }
    
    .page-title .icon-bg {
        background-color: #f0f2f5;
        width: 48px;
        height: 48px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
        color: #555;
    }

    .page-title h3 {
        margin: 0;
        font-size: 18px;
        color: #333;
    }
    .page-title p {
        margin: 0;
        font-size: 13px;
        color: #777;
    }

    .send-layout {
        display: grid;
        grid-template-columns: 280px 1fr;
        gap: 24px;
        background: #fff;
        padding: 24px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.05);
    }

    /* Left Column */
    .numbers-col h4 {
        text-align: center;
        font-size: 14px;
        margin-bottom: 12px;
        color: #333;
    }
    .numbers-textarea {
        width: 100%;
        height: 400px;
        resize: none;
        border: 1px solid #ddd;
        border-radius: 4px;
        padding: 12px;
        font-family: monospace;
        font-size: 13px;
    }
    .numbers-textarea:focus {
        outline: none;
        border-color: #4a90e2;
    }

    /* Right Column */
    .input-group {
        display: flex;
        margin-bottom: 16px;
    }
    .input-group-addon {
        background-color: #f05a5b;
        color: white;
        padding: 10px 16px;
        border-radius: 4px 0 0 4px;
        font-weight: 500;
        font-size: 14px;
        min-width: 120px;
        text-align: center;
    }
    .input-group-input {
        flex: 1;
        border: 1px solid #ddd;
        border-left: none;
        border-radius: 0 4px 4px 0;
        padding: 10px 16px;
        font-size: 14px;
    }
    .input-group-input:focus {
        outline: none;
        border-color: #4a90e2;
    }

    .message-textarea {
        width: 100%;
        height: 180px;
        resize: none;
        border: 1px solid #ddd;
        border-radius: 4px;
        padding: 12px;
        font-size: 14px;
        margin-bottom: 16px;
    }
    .message-textarea:focus {
        outline: none;
        border-color: #4a90e2;
    }

    /* Media & Buttons Row */
    .media-buttons-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 24px;
        margin-bottom: 24px;
    }

    .upload-box-wrapper {
        display: flex;
        flex-direction: column;
    }

    .upload-box {
        background-color: #f5f5f5;
        border: 1px dashed #ccc;
        border-radius: 4px;
        padding: 24px 12px;
        text-align: center;
        font-size: 13px;
        color: #555;
        cursor: pointer;
        position: relative;
        flex: 1;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-direction: column;
    }
    .upload-box:hover {
        background-color: #ebebeb;
    }
    .upload-box input[type="file"] {
        position: absolute;
        top: 0; left: 0; right: 0; bottom: 0;
        opacity: 0;
        cursor: pointer;
        width: 100%; height: 100%;
    }
    .upload-box a {
        text-decoration: underline;
        color: #333;
        font-weight: 500;
    }
    .upload-subtitle {
        text-align: center;
        font-size: 12px;
        font-weight: 600;
        margin-top: 8px;
    }
    .text-green { color: #009688; }

    /* Button Inputs */
    .buttons-wrapper {
        display: flex;
        flex-direction: column;
        justify-content: center;
        gap: 16px;
    }
    
    .btn-input-group {
        display: flex;
    }
    .btn-input-addon {
        background-color: #fff;
        border: 1px solid #ddd;
        color: #333;
        padding: 10px 16px;
        border-radius: 4px 0 0 4px;
        font-weight: 500;
        font-size: 13px;
        min-width: 100px;
    }
    .btn-input-field {
        flex: 1;
        border: 1px solid #ddd;
        border-left: none;
        border-radius: 0 4px 4px 0;
        padding: 10px 16px;
        font-size: 13px;
    }
    .btn-input-field:focus {
        outline: none;
        border-color: #4a90e2;
    }

    /* Warnings */
    .warning-text {
        color: #f05a5b;
        font-size: 12px;
        font-weight: 500;
        text-align: center;
        margin-bottom: 8px;
    }

    /* Footer */
    .form-footer {
        display: flex;
        align-items: center;
        gap: 16px;
        margin-top: 24px;
    }
    .btn-submit {
        background-color: #4a6ee0;
        color: white;
        border: none;
        padding: 12px 32px;
        border-radius: 4px;
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        box-shadow: 0 2px 4px rgba(74, 110, 224, 0.3);
    }
    .btn-submit:hover {
        background-color: #3858c2;
    }
    .schedule-wrap {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 14px;
        font-weight: 600;
        color: #333;
    }

    @media (max-width: 900px) {
        .send-layout {
            grid-template-columns: 1fr;
        }
        .media-buttons-row {
            grid-template-columns: 1fr;
        }
    }
</style>

<div class="page-title">
    <div class="icon-bg">
        <i class="fa-regular fa-envelope"></i>
    </div>
    <div>
        <h3>Wapp Btn Message</h3>
        <p>send btn wa message</p>
    </div>
    
    @isset($remainingQuota)
    <div style="margin-left: auto; font-weight: 600; color: #4a6ee0;">
        Daily Quota Remaining: {{ $remainingQuota }}
    </div>
    @endisset
</div>

<div class="warning-text" style="text-align: right; margin-bottom: 12px; font-weight: 400;">
    Note:Minimum 1000 number required for campaing. Do Not send any fraud or abuse Mesage.If we found any such content Your account will be suspended
</div>

<!-- Alerts handled by SweetAlert below -->
<form action="{{ route('send.wa.submit') }}" method="POST" enctype="multipart/form-data">
    @csrf
    <div class="send-layout">
        
        <!-- Left Column: Numbers -->
        <div class="numbers-col">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                <h4 style="margin: 0;">Numbers</h4>
                <div style="display: flex; gap: 8px;">
                    <a href="{{ asset('public/demo_contacts.csv') }}" download style="background: #e2e8f0; color: #475569; padding: 4px 10px; border-radius: 4px; font-size: 12px; font-weight: 600; text-decoration: none; border: 1px solid #cbd5e1; box-shadow: 0 1px 2px rgba(0,0,0,0.05); display: inline-flex; align-items: center; gap: 4px;"><i class="fa-solid fa-download"></i> Demo Excel</a>
                    <label style="background: #10b981; color: #fff; padding: 4px 10px; border-radius: 4px; font-size: 12px; cursor: pointer; font-weight: 600; box-shadow: 0 2px 4px rgba(16,185,129,0.2); display: inline-flex; align-items: center; gap: 4px; margin: 0;">
                        <i class="fa-solid fa-file-excel"></i> Upload Excel
                        <input type="file" id="excelUploadInput" accept=".xlsx, .xls, .csv" style="display: none;">
                    </label>
                </div>
            </div>
            <textarea name="phone_numbers" class="numbers-textarea" placeholder="Enter one number per line" required>{{ old('phone_numbers') }}</textarea>
        </div>

        <!-- Right Column: Form -->
        <div class="form-col">
            <div class="input-group">
                <div class="input-group-addon">Campaign</div>
                <select name="campaign_name" class="input-group-input" required>
                    <option value="custom_campaign" {{ old('campaign_name') == 'custom_campaign' ? 'selected' : '' }}>Custom Message (Free-form / Media / Buttons)</option>
                    @if(!empty($metaTemplates))
                        @foreach($metaTemplates as $tpl)
                            <option value="{{ $tpl['name'] }}" {{ old('campaign_name') == $tpl['name'] ? 'selected' : '' }}>
                                {{ ucwords(str_replace('_', ' ', $tpl['name'])) }} (Meta Template - {{ $tpl['status'] }})
                            </option>
                        @endforeach
                    @else
                        <option value="stm_digital" {{ old('campaign_name') == 'stm_digital' ? 'selected' : '' }}>STM Digital</option>
                        <option value="stm_customer_support" {{ old('campaign_name') == 'stm_customer_support' ? 'selected' : '' }}>STM Developments Official</option>
                        <option value="3p_direct_integration_test_template" {{ old('campaign_name') == '3p_direct_integration_test_template' ? 'selected' : '' }}>3P Direct Integration Test</option>
                    @endif
                </select>
            </div>

            <div class="input-group">
                <div class="input-group-addon"><i class="fa-regular fa-clock"></i> Schedule (Optional)</div>
                <input type="datetime-local" name="scheduled_at" class="input-group-input" value="{{ old('scheduled_at') }}">
            </div>

            <textarea name="message_text" class="message-textarea" placeholder="text message (Optional if using Template)" maxlength="300">{{ old('message_text') }}</textarea>

            <div class="media-buttons-row">
                <!-- Image/Media Upload -->
                <!-- <div class="upload-box-wrapper">
                    <div class="upload-box" id="drop-area">
                        Drag & Drop Media(image, pdf) or <br> <a>Click to Browse Media</a>
                        <input type="file" name="media_file" accept=".jpg,.jpeg,.png,.pdf,.mp4">
                    </div>
                    <div class="upload-subtitle text-green">Image Upload <span style="color:red">(Max file size 2 MB.)</span></div>
                </div> -->

                <div class="upload-box-wrapper">
    <div class="upload-box" id="drop-area">
        Drag & Drop Media (Images, PDF, Documents) or
        <br>
        <a href="javascript:void(0)">Click to Browse Media</a>

        <input 
            type="file"
            name="media_files[]"
            id="mediaFilesInput"
            accept=".jpg,.jpeg,.png,.gif,.pdf,.mp4,.doc,.docx,.xlsx,.xls,.cdr,.pmd,.psd"
            multiple
        >
    </div>

    <div class="upload-subtitle text-green">
        Multiple Files Upload
        <span style="color:red">(Max file size 2 MB each.)</span>
    </div>

    <div id="selectedFilesPreview"></div>
</div>

                <!-- Call to Action Buttons -->
                <div class="buttons-wrapper">
                    <div class="btn-input-group">
                        <div class="btn-input-addon">Visit Now</div>
                        <input type="url" name="visit_url" class="btn-input-field" placeholder="http://" value="{{ old('visit_url') }}">
                    </div>
                    <div class="btn-input-group">
                        <div class="btn-input-addon">Call Now</div>
                        <input type="text" name="call_number" class="btn-input-field" placeholder="10 Digit number" value="{{ old('call_number') }}">
                    </div>
                </div>
            </div>

        </div>
    </div>

    <!-- Footer -->
    <div class="form-footer">
        <button type="submit" class="btn-submit" {{ isset($remainingQuota) && $remainingQuota <= 0 ? 'disabled' : '' }}>Submit Now</button>
        <label class="schedule-wrap">
            <input type="checkbox" name="is_scheduled"> Schedule
        </label>
    </div>
</form>

<script>
    const mediaInput = document.getElementById('mediaFilesInput');
    if (mediaInput) {
        mediaInput.addEventListener('change', function(e) {
            let files = e.target.files;
            let box = document.getElementById('selectedFilesPreview');
            if(files && files.length > 0) {
                let fileNames = [];
                for (let i = 0; i < files.length; i++) {
                    fileNames.push(files[i].name);
                }
                box.innerHTML = '<div style="color:#009688; font-weight:600; margin-top: 10px;">Selected: <br>' + fileNames.join('<br>') + '</div>';
            } else {
                box.innerHTML = '';
            }
        });
    }
</script> 

<!-- Recent Activity Table -->
<div style="margin-top: 40px;">
    <h3 style="font-size: 16px; margin-bottom: 16px; color: #333;">Recent Activity</h3>
    <div style="background: #fff; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); overflow: hidden;">
        <table style="width: 100%; border-collapse: collapse; text-align: left;">
            <thead>
                <tr style="background-color: #f8f9fa; border-bottom: 2px solid #eee;">
                    <th style="padding: 12px 16px; font-weight: 600; color: #555;">Date</th>
                    <th style="padding: 12px 16px; font-weight: 600; color: #555;">Campaign</th>
                    <th style="padding: 12px 16px; font-weight: 600; color: #555;">Phone</th>
                    <th style="padding: 12px 16px; font-weight: 600; color: #555;">Status</th>
                </tr>
            </thead>
            <tbody>
                @forelse($recentLogs as $log)
                <tr style="border-bottom: 1px solid #eee;">
                    <td style="padding: 12px 16px; color: #666;">{{ $log->created_at->format('M d, Y H:i') }}</td>
                    <td style="padding: 12px 16px; font-weight: 500;">{{ $log->template_name }}</td>
                    <td style="padding: 12px 16px; color: #666;">{{ $log->phone_number }}</td>
                    <td style="padding: 12px 16px;">
                        @if($log->status === 'success')
                            <span style="background: #e8f5e9; color: #2e7d32; padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: 600;">Success</span>
                        @else
                            <span style="background: #ffebee; color: #c62828; padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: 600;">Failed</span>
                        @endif
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="4" style="padding: 24px; text-align: center; color: #999;">No recent messages sent.</td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

<!-- SweetAlert2 integration -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<!-- SheetJS for Excel Parsing -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
<script>
    // Excel Upload Logic
    document.getElementById('excelUploadInput').addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (!file) return;

        Swal.fire({
            title: 'Processing File',
            text: 'Extracting phone numbers...',
            allowOutsideClick: false,
            didOpen: () => { Swal.showLoading(); }
        });

        const reader = new FileReader();
        reader.onload = function(e) {
            try {
                const data = new Uint8Array(e.target.result);
                const workbook = XLSX.read(data, {type: 'array'});
                const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
                const json = XLSX.utils.sheet_to_json(firstSheet, {header: 1});
                
                let phoneNumbers = [];
                
                json.forEach(row => {
                    row.forEach(cell => {
                        if (cell) {
                            let str = String(cell).replace(/\D/g, ''); // strip non-digits
                            if (str.length >= 10 && str.length <= 15) {
                                phoneNumbers.push(str);
                            }
                        }
                    });
                });

                if (phoneNumbers.length > 0) {
                    const textarea = document.querySelector('textarea[name="phone_numbers"]');
                    let existing = textarea.value.trim();
                    let combined = existing ? existing + '\n' + phoneNumbers.join('\n') : phoneNumbers.join('\n');
                    
                    // Deduplicate
                    let uniqueNumbers = [...new Set(combined.split('\n').map(n => n.trim()).filter(n => n))];
                    textarea.value = uniqueNumbers.join('\n');
                    
                    Swal.fire({
                        icon: 'success',
                        title: 'Excel Processed',
                        text: `Found ${phoneNumbers.length} numbers (Total unique in box: ${uniqueNumbers.length}).`,
                        confirmButtonColor: '#4a6ee0'
                    });
                } else {
                    Swal.fire({
                        icon: 'warning',
                        title: 'No Numbers Found',
                        text: 'Could not find any valid phone numbers (10-15 digits) in the file.',
                        confirmButtonColor: '#f05a5b'
                    });
                }
            } catch (err) {
                Swal.fire({
                    icon: 'error',
                    title: 'Error reading file',
                    text: err.message,
                    confirmButtonColor: '#f05a5b'
                });
            }
            document.getElementById('excelUploadInput').value = '';
        };
        reader.readAsArrayBuffer(file);
    });

    @if(session('success'))
        Swal.fire({
            title: 'Success!',
            text: {!! json_encode(session('success')) !!},
            icon: 'success',
            confirmButtonColor: '#4a6ee0',
            confirmButtonText: 'Great'
        });
    @endif

    @if(session('status'))
        Swal.fire({
            title: 'Campaign Status',
            html: {!! json_encode(session('status')) !!},
            icon: 'info',
            confirmButtonColor: '#4a6ee0',
            confirmButtonText: 'OK'
        });
    @endif

    @if($errors->any())
        let errorMsg = "";
        @foreach($errors->all() as $error)
            errorMsg += {!! json_encode($error) !!} + "<br>";
        @endforeach
        
        Swal.fire({
            title: 'Action Failed',
            html: errorMsg,
            icon: 'error',
            confirmButtonColor: '#f05a5b',
            confirmButtonText: 'Try Again'
        });
    @endif
</script>
@endsection
